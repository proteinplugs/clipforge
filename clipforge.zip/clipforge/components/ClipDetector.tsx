'use client'
import { useState } from 'react'

const S = {
  panel: { background: '#0d1117', border: '1px solid #1c2128', borderRadius: 12, padding: 32 } as React.CSSProperties,
  label: { fontSize: 11, letterSpacing: 2, color: '#6e7681', textTransform: 'uppercase' as const, marginBottom: 8, display: 'block' },
  input: {
    background: '#050708', border: '1px solid #1c2128', borderRadius: 8,
    color: '#f5f2ec', fontFamily: "'IBM Plex Mono', monospace", fontSize: 13,
    padding: '12px 16px', width: '100%', outline: 'none',
  } as React.CSSProperties,
  btn: {
    fontFamily: 'Anton, sans-serif', fontSize: 16, letterSpacing: 2,
    padding: '13px 28px', borderRadius: 8, border: 'none', cursor: 'pointer',
    background: '#ff4d00', color: '#050708',
    boxShadow: '0 0 24px rgba(255,77,0,0.25)',
    transition: 'all .2s', display: 'inline-flex', alignItems: 'center', gap: 8,
  } as React.CSSProperties,
}

export default function ClipDetector() {
  const [url, setUrl] = useState('')
  const [topic, setTopic] = useState('')
  const [step, setStep] = useState<'idle' | 'transcript' | 'analyzing' | 'done' | 'error'>('idle')
  const [clips, setClips] = useState<any>(null)
  const [error, setError] = useState('')
  const [transcriptInfo, setTranscriptInfo] = useState<any>(null)

  const detect = async () => {
    if (!url.trim()) return
    setStep('transcript')
    setClips(null)
    setError('')

    try {
      // Step 1: Fetch real YouTube transcript
      const transcriptRes = await fetch('/api/transcript', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      })
      const transcriptData = await transcriptRes.json()
      if (!transcriptRes.ok) throw new Error(transcriptData.error)

      setTranscriptInfo(transcriptData)
      setStep('analyzing')

      // Step 2: Claude analyzes real transcript for viral clips
      const clipsRes = await fetch('/api/clips', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoId: transcriptData.videoId,
          chunks: transcriptData.chunks,
          topic,
        }),
      })
      const clipsData = await clipsRes.json()
      if (!clipsRes.ok) throw new Error(clipsData.error)

      setClips(clipsData)
      setStep('done')
    } catch (e: any) {
      setError(e.message)
      setStep('error')
    }
  }

  const emotionColor: Record<string, string> = {
    curiosity: '#00aaff', shock: '#ff4d00', inspiration: '#00e87a',
    humor: '#ffe600', relatability: '#ff8c42', controversy: '#ff3d71',
  }

  return (
    <div style={S.panel}>
      <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 28, letterSpacing: 1, marginBottom: 6 }}>VIRAL CLIP DETECTOR</div>
      <div style={{ fontSize: 13, color: '#6e7681', marginBottom: 28, lineHeight: 1.7 }}>
        Paste any YouTube URL. We pull the <strong style={{ color: '#f5f2ec' }}>real transcript</strong>, then AI finds your 4 best viral moments with exact timestamps.
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={S.label}>YouTube URL</label>
        <input
          style={S.input}
          type="text"
          placeholder="https://www.youtube.com/watch?v=..."
          value={url}
          onChange={e => setUrl(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && detect()}
        />
      </div>

      <div style={{ marginBottom: 24 }}>
        <label style={S.label}>Topic / Context (optional)</label>
        <input
          style={S.input}
          type="text"
          placeholder="e.g. motivation, tech review, comedy podcast..."
          value={topic}
          onChange={e => setTopic(e.target.value)}
        />
      </div>

      <button style={{ ...S.btn, opacity: step === 'transcript' || step === 'analyzing' ? .6 : 1 }}
        onClick={detect}
        disabled={step === 'transcript' || step === 'analyzing' || !url.trim()}>
        {step === 'transcript' ? '📡 Fetching transcript...' :
          step === 'analyzing' ? '🧠 Claude analyzing...' : '⚡ FIND VIRAL CLIPS'}
      </button>

      {/* Progress steps */}
      {(step === 'transcript' || step === 'analyzing' || step === 'done') && (
        <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { label: 'Fetching real YouTube transcript', done: step !== 'transcript' },
            { label: transcriptInfo ? `Analyzing ${transcriptInfo.totalChunks} transcript segments (${Math.round(transcriptInfo.durationSeconds / 60)} min video)` : 'Parsing transcript chunks', done: step === 'done' },
            { label: 'Claude scoring virality of each moment', done: step === 'done' },
          ].map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'center', fontSize: 13 }}>
              <div style={{
                width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
                background: s.done ? '#00e87a' : (
                  (i === 0 && step === 'transcript') || (i === 1 && step === 'analyzing') || (i === 2 && step === 'analyzing')
                    ? '#ff4d00' : '#1c2128'
                ),
                boxShadow: s.done ? '0 0 8px #00e87a' : 'none',
                transition: 'all .3s',
              }} />
              <span style={{ color: s.done ? '#f5f2ec' : '#6e7681' }}>{s.label}</span>
            </div>
          ))}
        </div>
      )}

      {step === 'error' && (
        <div style={{
          marginTop: 16, background: 'rgba(255,77,0,0.08)',
          border: '1px solid rgba(255,77,0,0.3)',
          borderRadius: 8, padding: '14px 18px',
          fontSize: 13, color: '#ff4d00',
        }}>
          ⚠ {error}
        </div>
      )}

      {/* Results */}
      {step === 'done' && clips && (
        <div style={{ marginTop: 32 }}>
          <div style={{ fontSize: 13, color: '#6e7681', marginBottom: 16 }}>
            📹 <strong style={{ color: '#f5f2ec' }}>{clips.video_title}</strong> · {clips.total_duration}
          </div>

          {clips.overall_analysis && (
            <div style={{
              background: 'rgba(0,232,122,0.06)', border: '1px solid rgba(0,232,122,0.15)',
              borderRadius: 8, padding: '12px 16px', fontSize: 12, color: '#6e7681',
              lineHeight: 1.7, marginBottom: 20,
            }}>
              🧠 {clips.overall_analysis}
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {clips.clips?.map((clip: any, i: number) => (
              <div key={i} style={{
                background: '#050708', border: '1px solid #1c2128',
                borderRadius: 10, padding: 20,
                animation: `fadeUp .3s ${i * 0.07}s ease both`,
              }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                  <span style={{
                    background: '#ff4d00', color: '#050708',
                    fontFamily: 'Anton, sans-serif', fontSize: 13,
                    padding: '2px 10px', borderRadius: 4,
                  }}>CLIP {clip.clip_number}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#6e7681' }}>
                    <span>{clip.viral_score}% viral</span>
                    <div style={{ width: 80, height: 6, background: '#1c2128', borderRadius: 3, overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${clip.viral_score}%`, background: 'linear-gradient(90deg,#ff4d00,#ffe600)', borderRadius: 3, transition: 'width .6s ease' }} />
                    </div>
                  </div>
                </div>

                {/* Timestamp */}
                <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 24, color: '#ff4d00', marginBottom: 8 }}>
                  ⏱ {clip.timestamp_start} → {clip.timestamp_end}
                </div>

                {/* Emotion badge */}
                {clip.emotion && (
                  <span style={{
                    fontSize: 10, letterSpacing: 1.5, textTransform: 'uppercase',
                    padding: '3px 10px', borderRadius: 20,
                    border: `1px solid ${emotionColor[clip.emotion] || '#1c2128'}40`,
                    color: emotionColor[clip.emotion] || '#6e7681',
                    marginBottom: 12, display: 'inline-block',
                  }}>{clip.emotion}</span>
                )}

                {/* Hook */}
                <div style={{
                  background: 'rgba(255,77,0,0.06)', borderLeft: '3px solid #ff4d00',
                  padding: '10px 14px', borderRadius: '0 6px 6px 0',
                  fontSize: 13, fontStyle: 'italic', color: '#f5f2ec', marginBottom: 10,
                }}>
                  💬 "{clip.hook}"
                </div>

                {/* Key quote */}
                {clip.key_quote && (
                  <div style={{ fontSize: 12, color: '#00e87a', marginBottom: 8, fontStyle: 'italic' }}>
                    📌 Key line: "{clip.key_quote}"
                  </div>
                )}

                {/* Why viral */}
                <div style={{ fontSize: 13, color: '#6e7681', lineHeight: 1.7, marginBottom: 10 }}>
                  {clip.why_viral}
                </div>

                {/* Caption */}
                {clip.caption && (
                  <div style={{
                    background: '#0d1117', border: '1px solid #1c2128',
                    borderRadius: 6, padding: '8px 12px',
                    fontSize: 12, color: '#00aaff', marginBottom: 12,
                  }}>
                    📝 Caption: {clip.caption}
                  </div>
                )}

                {/* Tags */}
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {clip.tags?.map((t: string) => (
                    <span key={t} style={{
                      fontSize: 11, padding: '3px 10px', borderRadius: 20,
                      border: '1px solid #1c2128', color: '#6e7681',
                    }}>#{t}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}`}</style>
    </div>
  )
}
