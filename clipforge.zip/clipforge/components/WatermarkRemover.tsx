'use client'
import { useState, useRef } from 'react'

const S = {
  panel: { background: '#0d1117', border: '1px solid #1c2128', borderRadius: 12, padding: 32 } as React.CSSProperties,
  btn: (color = '#ff4d00') => ({
    fontFamily: 'Anton, sans-serif', fontSize: 16, letterSpacing: 2,
    padding: '13px 28px', borderRadius: 8, border: 'none', cursor: 'pointer',
    background: color, color: color === '#ff4d00' ? '#050708' : '#fff',
    transition: 'all .2s', display: 'inline-flex', alignItems: 'center', gap: 8,
  } as React.CSSProperties),
}

const STEPS = [
  'Uploading video to processing queue',
  'Scanning frames for watermark regions',
  'Running AI detection model (SAM)',
  'Inpainting background behind watermarks',
  'Temporal smoothing across frames',
  'Encoding final clean video',
]

export default function WatermarkRemover() {
  const [file, setFile] = useState<File | null>(null)
  const [dragging, setDragging] = useState(false)
  const [loading, setLoading] = useState(false)
  const [stepsDone, setStepsDone] = useState(0)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  const process = async () => {
    if (!file) return
    setLoading(true); setResult(null); setError(''); setStepsDone(0)

    try {
      // Animate steps while uploading
      for (let i = 0; i < STEPS.length - 1; i++) {
        await new Promise(r => setTimeout(r, 900 + Math.random() * 500))
        setStepsDone(i + 1)
      }

      const formData = new FormData()
      formData.append('video', file)
      formData.append('maskType', 'auto')

      const res = await fetch('/api/watermark', { method: 'POST', body: formData })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)

      setStepsDone(STEPS.length)
      setResult(data)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={S.panel}>
      <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 28, letterSpacing: 1, marginBottom: 6 }}>WATERMARK REMOVER</div>
      <div style={{ fontSize: 13, color: '#6e7681', marginBottom: 28, lineHeight: 1.7 }}>
        Upload any video with watermarks. AI detects and inpaints them frame-by-frame, preserving background detail.
      </div>

      {/* Upload zone */}
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) setFile(f) }}
        style={{
          border: `2px dashed ${dragging ? '#ff4d00' : '#1c2128'}`,
          borderRadius: 10, padding: '40px 24px',
          textAlign: 'center', cursor: 'pointer',
          background: dragging ? 'rgba(255,77,0,0.04)' : 'transparent',
          transition: 'all .2s', marginBottom: 20,
        }}
      >
        <input ref={inputRef} type="file" accept="video/*" style={{ display: 'none' }}
          onChange={e => { const f = e.target.files?.[0]; if (f) setFile(f) }} />
        <div style={{ fontSize: 36, marginBottom: 12 }}>🎬</div>
        {file ? (
          <div style={{ fontSize: 14, color: '#f5f2ec' }}>
            <strong>{file.name}</strong><br />
            <span style={{ color: '#6e7681', fontSize: 12 }}>{(file.size / 1048576).toFixed(1)} MB</span>
          </div>
        ) : (
          <div style={{ fontSize: 14, color: '#6e7681' }}>
            <strong style={{ color: '#ff4d00' }}>Drop video here</strong> or click to browse<br />
            <span style={{ fontSize: 12 }}>MP4, MOV, AVI supported</span>
          </div>
        )}
      </div>

      <button style={{ ...S.btn('#ff3d71'), opacity: loading || !file ? .6 : 1 }}
        onClick={process} disabled={loading || !file}>
        {loading ? '🔧 Processing...' : '🔧 REMOVE WATERMARKS'}
      </button>

      {/* Steps */}
      {(loading || result) && (
        <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {STEPS.map((s, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'center', fontSize: 13 }}>
              <div style={{
                width: 8, height: 8, borderRadius: '50%', flexShrink: 0,
                background: stepsDone > i ? '#00e87a' : (loading && stepsDone === i ? '#ff4d00' : '#1c2128'),
                boxShadow: stepsDone > i ? '0 0 8px #00e87a' : 'none',
                transition: 'all .3s',
              }} />
              <span style={{ color: stepsDone > i ? '#f5f2ec' : '#6e7681' }}>{s}</span>
            </div>
          ))}
        </div>
      )}

      {error && (
        <div style={{ marginTop: 16, background: 'rgba(255,77,0,0.08)', border: '1px solid rgba(255,77,0,0.3)', borderRadius: 8, padding: '14px 18px', fontSize: 13, color: '#ff4d00' }}>
          ⚠ {error}
        </div>
      )}

      {result && (
        <div style={{ marginTop: 24 }}>
          {/* Before/After */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            {[['Original', '🎞', '#0d1117'], ['Cleaned ✨', '✨', '#0a1f10']].map(([label, icon, bg]) => (
              <div key={label} style={{ background: '#050708', border: '1px solid #1c2128', borderRadius: 10, overflow: 'hidden' }}>
                <div style={{ padding: '10px 14px', fontSize: 11, letterSpacing: 1.5, color: '#6e7681', textTransform: 'uppercase', borderBottom: '1px solid #1c2128' }}>{label}</div>
                <div style={{ aspectRatio: '16/9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, background: bg }}>
                  {icon}
                  {result.output_url && label.includes('Cleaned') && (
                    <video src={result.output_url} controls style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div style={{ background: '#050708', border: '1px solid #1c2128', borderRadius: 10, padding: 20 }}>
            <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap', marginBottom: 12 }}>
              {[
                ['Watermarks Found', result.watermarks_found, '#ff4d00'],
                ['Confidence', `${result.confidence}%`, '#f5f2ec'],
                ['Quality Score', `${result.quality_score}/100`, '#00e87a'],
                ['Process Time', `${result.processing_time_s}s`, '#00aaff'],
              ].map(([k, v, c]) => (
                <div key={k as string}>
                  <div style={{ fontSize: 10, letterSpacing: 1.5, color: '#6e7681', textTransform: 'uppercase', marginBottom: 3 }}>{k}</div>
                  <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 22, color: c as string }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 12, color: '#6e7681', lineHeight: 1.7 }}>{result.notes}</div>
            {result.demo && (
              <div style={{ marginTop: 12, fontSize: 11, color: '#ff8c42', background: 'rgba(255,140,66,0.08)', border: '1px solid rgba(255,140,66,0.2)', borderRadius: 6, padding: '8px 12px' }}>
                💡 Demo mode — add <code>REPLICATE_API_TOKEN</code> to .env.local for real watermark removal
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
