'use client'
import { useState } from 'react'

const S = {
  panel: { background: '#0d1117', border: '1px solid #1c2128', borderRadius: 12, padding: 32 } as React.CSSProperties,
  label: { fontSize: 11, letterSpacing: 2, color: '#6e7681', textTransform: 'uppercase' as const, marginBottom: 8, display: 'block' },
  input: { background: '#050708', border: '1px solid #1c2128', borderRadius: 8, color: '#f5f2ec', fontFamily: "'IBM Plex Mono', monospace", fontSize: 13, padding: '12px 16px', width: '100%', outline: 'none' } as React.CSSProperties,
  select: { background: '#050708', border: '1px solid #1c2128', borderRadius: 8, color: '#f5f2ec', fontFamily: "'IBM Plex Mono', monospace", fontSize: 13, padding: '12px 16px', width: '100%', outline: 'none' } as React.CSSProperties,
}

export default function VideoGenerator() {
  const [script, setScript] = useState('')
  const [platform, setPlatform] = useState('tiktok')
  const [style, setStyle] = useState('cinematic')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  const generate = async () => {
    if (!script.trim()) return
    setLoading(true); setResult(null); setError('')

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ script, platform, style }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setResult(data)
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const platformColor: Record<string, string> = {
    'TikTok 9:16': '#ff0050', 'Instagram Reels': '#e1306c', 'YouTube Shorts': '#ff0000',
  }

  return (
    <div style={S.panel}>
      <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 28, letterSpacing: 1, marginBottom: 6 }}>AI VIDEO GENERATOR</div>
      <div style={{ fontSize: 13, color: '#6e7681', marginBottom: 28, lineHeight: 1.7 }}>
        Write your script or hook. AI plans every scene, selects visuals, writes captions, picks music — then generates the actual video via RunwayML.
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={S.label}>Script / Hook</label>
        <textarea
          style={{ ...S.input, minHeight: 130, resize: 'vertical' } as React.CSSProperties}
          placeholder="Write your script here... e.g. '3 things I wish I knew before starting a business. Number one: your first idea is never your best idea...'"
          value={script}
          onChange={e => setScript(e.target.value)}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <div>
          <label style={S.label}>Platform</label>
          <select style={S.select} value={platform} onChange={e => setPlatform(e.target.value)}>
            <option value="tiktok">TikTok</option>
            <option value="youtube_shorts">YouTube Shorts</option>
            <option value="instagram">Instagram Reels</option>
            <option value="all">All Platforms</option>
          </select>
        </div>
        <div>
          <label style={S.label}>Visual Style</label>
          <select style={S.select} value={style} onChange={e => setStyle(e.target.value)}>
            <option value="cinematic">Cinematic</option>
            <option value="minimal">Clean & Minimal</option>
            <option value="bold_text">Bold Text / Meme</option>
            <option value="documentary">Documentary</option>
            <option value="vlog">Vlog / Talking Head</option>
            <option value="animated">Animated / Motion</option>
          </select>
        </div>
      </div>

      <button
        style={{ fontFamily: 'Anton, sans-serif', fontSize: 16, letterSpacing: 2, padding: '13px 28px', borderRadius: 8, border: 'none', cursor: 'pointer', background: '#ff4d00', color: '#050708', opacity: loading || !script.trim() ? .6 : 1 }}
        onClick={generate} disabled={loading || !script.trim()}>
        {loading ? '🎬 Generating...' : '🎬 GENERATE VIDEO'}
      </button>

      {loading && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, padding: '40px 0', color: '#6e7681', fontSize: 14 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', border: '3px solid #1c2128', borderTopColor: '#ff4d00', animation: 'spin .8s linear infinite' }} />
          <span>Scripting scenes, selecting visuals, optimising for {platform}...</span>
          <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </div>
      )}

      {error && (
        <div style={{ marginTop: 16, background: 'rgba(255,77,0,0.08)', border: '1px solid rgba(255,77,0,0.3)', borderRadius: 8, padding: '14px 18px', fontSize: 13, color: '#ff4d00' }}>
          ⚠ {error}
        </div>
      )}

      {result && (
        <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Video preview card */}
          <div style={{ background: '#050708', border: '1px solid #1c2128', borderRadius: 10, padding: 24 }}>
            <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <div style={{ width: 100, aspectRatio: '9/16', background: 'linear-gradient(160deg,#0d1f2d,#0a1520)', borderRadius: 10, border: '1px solid #1c2128', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, flexShrink: 0 }}>
                🎞
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 22, lineHeight: 1.1, marginBottom: 14 }}>{result.title}</div>
                <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', marginBottom: 12 }}>
                  {[
                    ['Duration', `${result.duration_seconds}s`],
                    ['Ratio', result.aspect_ratio],
                    ['Color Grade', result.color_grade],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <div style={{ fontSize: 10, letterSpacing: 1.5, color: '#6e7681', textTransform: 'uppercase', marginBottom: 3 }}>{k}</div>
                      <div style={{ fontSize: 14, fontWeight: 500 }}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ fontSize: 12, color: '#6e7681', marginBottom: 8 }}>🎵 {result.music_suggestion}</div>
                <div style={{ fontSize: 12, color: '#6e7681', marginBottom: 12 }}>📝 {result.caption_style}</div>

                {/* Platform badges */}
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {result.export_formats?.map((f: string) => (
                    <span key={f} style={{
                      padding: '4px 12px', borderRadius: 20, fontSize: 11, fontWeight: 600,
                      border: `1px solid ${platformColor[f] || '#1c2128'}`,
                      color: platformColor[f] || '#6e7681',
                    }}>{f}</span>
                  ))}
                </div>

                {/* Hooks analysis */}
                {result.hooks_analysis && (
                  <div style={{ marginTop: 12, fontSize: 12, color: '#00e87a', fontStyle: 'italic' }}>
                    💡 {result.hooks_analysis}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Scene breakdown */}
          <div style={{ fontSize: 11, letterSpacing: 2, color: '#6e7681', textTransform: 'uppercase' }}>Scene Breakdown</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {result.scenes?.map((scene: any) => (
              <div key={scene.scene_number} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', background: '#050708', border: '1px solid #1c2128', borderRadius: 8, padding: 14, fontSize: 13 }}>
                <span style={{ background: '#ff3d71', color: '#fff', fontFamily: 'Anton, sans-serif', fontSize: 12, padding: '2px 8px', borderRadius: 4, flexShrink: 0 }}>
                  S{scene.scene_number} · {scene.duration_s}s
                </span>
                <div style={{ color: '#6e7681', lineHeight: 1.6 }}>
                  <strong style={{ color: '#f5f2ec' }}>{scene.visual}</strong><br />
                  {scene.voiceover && <em>🎙 {scene.voiceover}<br /></em>}
                  {scene.text_overlay && <span style={{ color: '#ff4d00', fontSize: 12 }}>📝 {scene.text_overlay}</span>}
                </div>
              </div>
            ))}
          </div>

          {/* RunwayML status */}
          {result.message && (
            <div style={{ background: 'rgba(0,170,255,0.06)', border: '1px solid rgba(0,170,255,0.2)', borderRadius: 8, padding: '12px 16px', fontSize: 12, color: '#00aaff' }}>
              🎬 {result.message}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
