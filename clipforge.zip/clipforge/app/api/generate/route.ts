import { NextRequest, NextResponse } from 'next/server'

async function callGemini(prompt: string): Promise<string> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.8, maxOutputTokens: 1500 },
      }),
    }
  )
  const data = await res.json()
  if (data.error) throw new Error(data.error.message)
  return data.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

export async function POST(req: NextRequest) {
  try {
    const { script, platform, style } = await req.json()

    if (!script) {
      return NextResponse.json({ error: 'Script is required' }, { status: 400 })
    }

    const prompt = `You are an AI video director. Create a complete short-form video production plan.

Script: "${script}"
Platform: ${platform || 'tiktok'}
Style: ${style || 'cinematic'}

Return ONLY valid JSON, no markdown, no explanation:
{
  "title": "video title",
  "duration_seconds": 20,
  "aspect_ratio": "9:16",
  "scenes": [
    {
      "scene_number": 1,
      "duration_s": 5,
      "visual": "exact visual description",
      "voiceover": "exact words spoken",
      "text_overlay": "caption text on screen",
      "runway_prompt": "optimized prompt for AI video generation"
    }
  ],
  "music_suggestion": "specific genre and mood",
  "color_grade": "color grade style",
  "caption_style": "bold white text, black outline",
  "export_formats": ["TikTok 9:16", "Instagram Reels", "YouTube Shorts"],
  "hooks_analysis": "why the opening hook works",
  "estimated_views": "realistic view range"
}`

    const raw = await callGemini(prompt)
    const plan = JSON.parse(raw.replace(/```json|```/g, '').trim())

    return NextResponse.json({
      ...plan,
      status: 'plan_ready',
      message: 'Production plan ready. Add RUNWAYML_API_KEY to .env.local to render the actual video.',
    })

  } catch (error: any) {
    console.error('Video generation error:', error)
    return NextResponse.json({ error: error.message || 'Failed to generate video plan' }, { status: 500 })
  }
}
