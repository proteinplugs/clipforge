import { NextRequest, NextResponse } from 'next/server'
import { YoutubeTranscript } from 'youtube-transcript'

function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/, // raw ID
  ]
  for (const pattern of patterns) {
    const match = url.match(pattern)
    if (match) return match[1]
  }
  return null
}

export async function POST(req: NextRequest) {
  try {
    const { url } = await req.json()

    if (!url) {
      return NextResponse.json({ error: 'YouTube URL is required' }, { status: 400 })
    }

    const videoId = extractVideoId(url)
    if (!videoId) {
      return NextResponse.json({ error: 'Could not extract video ID from URL' }, { status: 400 })
    }

    // Fetch real transcript from YouTube
    const transcript = await YoutubeTranscript.fetchTranscript(videoId, {
      lang: 'en',
    })

    if (!transcript || transcript.length === 0) {
      return NextResponse.json({ error: 'No transcript available for this video. Try a video with captions enabled.' }, { status: 404 })
    }

    // Group transcript into 20-second chunks for analysis
    const chunks: { text: string; start: number; end: number }[] = []
    let currentChunk = { text: '', start: transcript[0].offset / 1000, end: 0 }

    for (const item of transcript) {
      const startSec = item.offset / 1000
      const chunkStart = currentChunk.start

      if (startSec - chunkStart >= 20) {
        currentChunk.end = startSec
        chunks.push({ ...currentChunk })
        currentChunk = { text: item.text, start: startSec, end: 0 }
      } else {
        currentChunk.text += ' ' + item.text
      }
    }
    // Push last chunk
    if (currentChunk.text) {
      currentChunk.end = currentChunk.start + 20
      chunks.push(currentChunk)
    }

    return NextResponse.json({
      videoId,
      totalSegments: transcript.length,
      totalChunks: chunks.length,
      durationSeconds: Math.round((transcript[transcript.length - 1].offset + transcript[transcript.length - 1].duration) / 1000),
      chunks: chunks.slice(0, 100), // Return first 100 chunks (covers ~33 min)
      fullTranscript: transcript.slice(0, 500), // First 500 raw segments
    })

  } catch (error: any) {
    console.error('Transcript error:', error)

    // Friendly errors
    if (error.message?.includes('Could not get transcripts')) {
      return NextResponse.json({
        error: 'This video has no captions. Try a video with auto-generated or manual captions.',
      }, { status: 404 })
    }

    return NextResponse.json({ error: error.message || 'Failed to fetch transcript' }, { status: 500 })
  }
}
