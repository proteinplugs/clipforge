import { NextRequest, NextResponse } from 'next/server'

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

async function callGemini(prompt: string): Promise<string> {
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 1500 },
      }),
    }
  )
  const data = await res.json()
  if (data.error) throw new Error(data.error.message)
  return data.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

export async function POST(req: NextRequest) {
  try {
    const { videoId, chunks, videoTitle, topic } = await req.json()

    if (!chunks || chunks.length === 0) {
      return NextResponse.json({ error: 'No transcript chunks provided' }, { status: 400 })
    }

    const sampleChunks = chunks.length > 60
      ? chunks.filter((_: any, i: number) => i % 3 === 0)
      : chunks

    const transcriptText = sampleChunks
      .map((c: any) => `[${formatTime(c.start)}–${formatTime(c.end)}] ${c.text.trim()}`)
      .join('\n')

    const prompt = `You are a world-class viral content strategist. Analyze this real YouTube transcript and find the 4 BEST ~20-second clips that could go viral on TikTok, Instagram Reels, or YouTube Shorts.

Video ID: ${videoId}
${videoTitle ? `Title: ${videoTitle}` : ''}
Topic: ${topic || 'general content'}

TRANSCRIPT:
${transcriptText}

For each clip:
1. Use EXACT timestamps from the transcript
2. Quote key lines from the actual text
3. Explain specifically WHY it will go viral
4. Suggest a scroll-stopping caption

Return ONLY valid JSON, no markdown, no explanation:
{
  "video_title": "inferred title",
  "total_duration": "estimated duration",
  "clips": [
    {
      "clip_number": 1,
      "timestamp_start": "MM:SS",
      "timestamp_end": "MM:SS",
      "viral_score": 85,
      "hook": "exact opening line from transcript",
      "key_quote": "most quotable line",
      "why_viral": "specific viral trigger explanation",
      "caption": "scroll-stopping TikTok caption",
      "emotion": "curiosity",
      "tags": ["tag1", "tag2", "tag3", "tag4"]
    }
  ],
  "overall_analysis": "brief viral potential analysis"
}`

    const raw = await callGemini(prompt)
    const cleaned = raw.replace(/```json|```/g, '').trim()
    const result = JSON.parse(cleaned)

    return NextResponse.json(result)

  } catch (error: any) {
    console.error('Clips analysis error:', error)
    return NextResponse.json({ error: error.message || 'Failed to analyze clips' }, { status: 500 })
  }
}
