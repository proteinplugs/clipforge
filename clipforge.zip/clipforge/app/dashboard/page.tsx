'use client'
import { useState } from 'react'
import ClipDetector from '../../components/ClipDetector'
import WatermarkRemover from '../../components/WatermarkRemover'
import VideoGenerator from '../../components/VideoGenerator'
import Link from 'next/link'

const TABS = [
  { id: 'clips', label: 'Viral Clip Detector', icon: '⚡' },
  { id: 'watermark', label: 'Watermark Remover', icon: '🔧' },
  { id: 'generate', label: 'AI Video Generator', icon: '🎬' },
]

export default function Dashboard() {
  const [tab, setTab] = useState('clips')

  return (
    <div style={{ minHeight: '100vh', background: '#050708', fontFamily: "'IBM Plex Mono', monospace" }}>
      {/* Top bar */}
      <div style={{
        borderBottom: '1px solid #1c2128',
        padding: '16px 32px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'rgba(5,7,8,0.95)', position: 'sticky', top: 0, zIndex: 50,
      }}>
        <Link href="/" style={{ textDecoration: 'none' }}>
          <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 20, letterSpacing: 2, color: '#f5f2ec' }}>
            CLIP<span style={{ color: '#ff4d00' }}>FORGE</span>
          </span>
        </Link>
        <div style={{ fontSize: 11, letterSpacing: 2, color: '#6e7681', textTransform: 'uppercase' }}>
          Dashboard · Free Plan
        </div>
        <div style={{
          fontSize: 11, letterSpacing: 1.5, color: '#00e87a',
          background: 'rgba(0,232,122,0.08)', border: '1px solid rgba(0,232,122,0.2)',
          padding: '4px 12px', borderRadius: 20,
        }}>
          ● Live
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '40px 24px 80px' }}>
        {/* Header */}
        <div style={{ marginBottom: 36 }}>
          <h1 style={{ fontFamily: 'Anton, sans-serif', fontSize: 'clamp(32px,5vw,52px)', letterSpacing: -1, marginBottom: 8 }}>
            YOUR CONTENT STUDIO
          </h1>
          <p style={{ fontSize: 13, color: '#6e7681', lineHeight: 1.7 }}>
            Paste a YouTube link → get real viral clips from the actual transcript.
            Upload a video → remove watermarks. Write a script → generate a full AI video.
          </p>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 6, marginBottom: 32, flexWrap: 'wrap' }}>
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                padding: '10px 20px', borderRadius: 8,
                border: `1px solid ${tab === t.id ? '#ff4d00' : '#1c2128'}`,
                background: tab === t.id ? '#ff4d00' : 'transparent',
                color: tab === t.id ? '#050708' : '#6e7681',
                fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 13, fontWeight: tab === t.id ? 700 : 400,
                cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 8,
                transition: 'all .2s',
                boxShadow: tab === t.id ? '0 0 24px rgba(255,77,0,0.25)' : 'none',
              }}
            >
              <span>{t.icon}</span> {t.label}
            </button>
          ))}
        </div>

        {/* Panel */}
        <div key={tab} style={{ animation: 'fadeUp .3s ease both' }}>
          {tab === 'clips' && <ClipDetector />}
          {tab === 'watermark' && <WatermarkRemover />}
          {tab === 'generate' && <VideoGenerator />}
        </div>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}
