import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ClipForge — Turn Any Video Viral',
  description: 'AI-powered viral clip detection, watermark removal, and video generation for TikTok, Reels & YouTube Shorts.',
  keywords: 'viral clips, short form video, watermark remover, AI video generator, TikTok, YouTube Shorts',
  openGraph: {
    title: 'ClipForge',
    description: 'Turn any long-form video into viral short clips with AI',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
