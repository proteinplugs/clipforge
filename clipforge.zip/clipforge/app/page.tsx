'use client'
import Link from 'next/link'
import { useState, useEffect } from 'react'

export default function Home() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <main style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
      {/* NAV */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 48px',
        borderBottom: scrolled ? '1px solid #1c2128' : '1px solid transparent',
        background: scrolled ? 'rgba(5,7,8,0.9)' : 'transparent',
        backdropFilter: scrolled ? 'blur(16px)' : 'none',
        transition: 'all 0.3s',
      }}>
        <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 22, letterSpacing: 2 }}>
          CLIP<span style={{ color: '#ff4d00' }}>FORGE</span>
        </span>
        <div style={{ display: 'flex', gap: 32, alignItems: 'center' }}>
          <a href="#features" style={{ fontSize: 11, letterSpacing: 2, color: '#6e7681', textDecoration: 'none', textTransform: 'uppercase' }}>Features</a>
          <a href="#pricing" style={{ fontSize: 11, letterSpacing: 2, color: '#6e7681', textDecoration: 'none', textTransform: 'uppercase' }}>Pricing</a>
          <Link href="/dashboard" style={{
            background: '#ff4d00', color: '#050708',
            fontFamily: 'Anton, sans-serif', fontSize: 14, letterSpacing: 2,
            padding: '10px 24px', borderRadius: 4, textDecoration: 'none',
          }}>
            OPEN APP →
          </Link>
        </div>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center',
        textAlign: 'center', padding: '140px 24px 80px',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Grid background */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(255,77,0,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(255,77,0,.06) 1px,transparent 1px)',
          backgroundSize: '60px 60px',
          maskImage: 'radial-gradient(ellipse 80% 80% at 50% 50%,black 40%,transparent 100%)',
          WebkitMaskImage: 'radial-gradient(ellipse 80% 80% at 50% 50%,black 40%,transparent 100%)',
        }} />

        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 10,
          background: 'rgba(255,77,0,.1)', border: '1px solid rgba(255,77,0,.25)',
          borderRadius: 40, padding: '6px 18px',
          fontSize: 11, letterSpacing: 2, color: '#ff4d00',
          textTransform: 'uppercase', marginBottom: 36,
        }}>
          🔴 Now in Beta — 200 Creators Already Inside
        </div>

        <h1 style={{
          fontFamily: 'Anton, sans-serif',
          fontSize: 'clamp(72px, 13vw, 160px)',
          lineHeight: 0.88, letterSpacing: -2,
          marginBottom: 8,
        }}>
          TURN ANY VIDEO
        </h1>
        <h1 style={{
          fontFamily: 'Instrument Serif, serif', fontStyle: 'italic',
          fontSize: 'clamp(52px, 9vw, 110px)',
          color: '#ff4d00', lineHeight: 1, marginBottom: 32,
        }}>
          Viral in Seconds
        </h1>

        <p style={{ maxWidth: 520, fontSize: 14, lineHeight: 1.8, color: '#6e7681', marginBottom: 48 }}>
          Drop a 2-hour YouTube video. ClipForge finds the 20-second gold, strips watermarks,
          and generates platform-ready short content — automatically.
        </p>

        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link href="/dashboard" style={{
            fontFamily: 'Anton, sans-serif', fontSize: 18, letterSpacing: 2,
            padding: '16px 40px', borderRadius: 4, textDecoration: 'none',
            background: '#ff4d00', color: '#050708',
            boxShadow: '0 0 40px rgba(255,77,0,.3)',
          }}>
            START FOR FREE →
          </Link>
          <a href="#features" style={{
            fontFamily: 'Anton, sans-serif', fontSize: 18, letterSpacing: 2,
            padding: '16px 40px', borderRadius: 4, textDecoration: 'none',
            border: '1px solid #1c2128', color: '#f5f2ec',
          }}>
            SEE HOW IT WORKS
          </a>
        </div>

        {/* Ticker */}
        <div style={{
          width: '100%', overflow: 'hidden',
          borderTop: '1px solid #1c2128', borderBottom: '1px solid #1c2128',
          padding: '14px 0', marginTop: 60,
          background: 'rgba(255,77,0,.03)',
        }}>
          <div style={{
            display: 'flex', width: 'max-content',
            animation: 'ticker 22s linear infinite',
          }}>
            {[...Array(2)].map((_, i) => (
              <span key={i} style={{ display: 'flex' }}>
                {['⚡ VIRAL CLIP DETECTION', '✦ WATERMARK REMOVAL', '🎬 AI VIDEO GENERATION',
                  '✦ TIKTOK · REELS · SHORTS', '⚡ TRANSCRIPT ANALYSIS', '✦ ONE-CLICK EXPORT'].map(item => (
                  <span key={item} style={{
                    fontSize: 11, letterSpacing: 3, textTransform: 'uppercase',
                    color: '#6e7681', padding: '0 40px', whiteSpace: 'nowrap',
                  }}>{item}</span>
                ))}
              </span>
            ))}
          </div>
        </div>
        <style>{`@keyframes ticker{from{transform:translateX(0)}to{transform:translateX(-50%)}}`}</style>
      </section>

      {/* STATS */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', borderTop: '1px solid #1c2128', borderBottom: '1px solid #1c2128' }}>
        {[['12M+','Clips Generated'],['94%','Viral Accuracy'],['20s','Avg Processing'],['3×','Engagement Lift']].map(([num, label]) => (
          <div key={label} style={{ padding: '48px 32px', textAlign: 'center', borderRight: '1px solid #1c2128' }}>
            <div style={{
              fontFamily: 'Anton, sans-serif', fontSize: 'clamp(40px,5vw,64px)',
              background: 'linear-gradient(135deg,#f5f2ec,#ff4d00)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>{num}</div>
            <div style={{ fontSize: 11, letterSpacing: 2, color: '#6e7681', textTransform: 'uppercase', marginTop: 6 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* FEATURES */}
      <section id="features" style={{ padding: '100px 48px', maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: '#ff4d00', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ display: 'block', width: 24, height: 1, background: '#ff4d00' }} />
          What ClipForge Does
        </div>
        <h2 style={{ fontFamily: 'Anton, sans-serif', fontSize: 'clamp(40px,5vw,72px)', lineHeight: .95, letterSpacing: -1, marginBottom: 60 }}>
          THREE TOOLS.<br />
          <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', color: '#ff4d00' }}>One workflow.</span>
        </h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 1, background: '#1c2128', border: '1px solid #1c2128', borderRadius: 12, overflow: 'hidden' }}>
          {[
            { icon: '⚡', num: '01', name: 'VIRAL CLIP DETECTOR', desc: 'Paste any YouTube URL. AI reads the real transcript, scores every segment, and surfaces the exact timestamps most likely to blow up.', badge: 'Claude AI + Real Transcripts', badgeColor: '#00e87a' },
            { icon: '🔧', num: '02', name: 'WATERMARK REMOVER', desc: 'Upload any video. Frame-level AI detection finds watermark regions, then inpainting reconstructs the background — frame by frame.', badge: 'Replicate Inpainting', badgeColor: '#00aaff' },
            { icon: '🎬', num: '03', name: 'AI VIDEO GENERATOR', desc: 'Write a script. AI plans every scene, selects visuals, writes captions, picks music, and exports for TikTok, Reels, and Shorts.', badge: 'RunwayML / Kling', badgeColor: '#ff8c42' },
          ].map(f => (
            <div key={f.num} style={{ background: '#050708', padding: 40 }}>
              <span style={{ fontSize: 32, marginBottom: 20, display: 'block' }}>{f.icon}</span>
              <div style={{ fontSize: 10, letterSpacing: 2, color: '#ff4d00', marginBottom: 10 }}>{f.num} / FEATURE</div>
              <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 24, letterSpacing: 1, marginBottom: 10 }}>{f.name}</div>
              <div style={{ fontSize: 12, lineHeight: 1.8, color: '#6e7681' }}>{f.desc}</div>
              <span style={{
                display: 'inline-block', marginTop: 16,
                fontSize: 10, letterSpacing: 1.5, textTransform: 'uppercase',
                padding: '4px 12px', borderRadius: 20,
                border: `1px solid ${f.badgeColor}40`, color: f.badgeColor,
              }}>{f.badge}</span>
            </div>
          ))}
        </div>
      </section>

      {/* PRICING */}
      <section id="pricing" style={{ padding: '100px 48px', maxWidth: 1200, margin: '0 auto', borderTop: '1px solid #1c2128' }}>
        <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: '#ff4d00', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ display: 'block', width: 24, height: 1, background: '#ff4d00' }} />
          Pricing
        </div>
        <h2 style={{ fontFamily: 'Anton, sans-serif', fontSize: 'clamp(40px,5vw,72px)', lineHeight: .95, marginBottom: 60 }}>
          SIMPLE PRICING.<br />
          <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', color: '#ff4d00' }}>Serious results.</span>
        </h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {[
            {
              tier: 'Starter', name: 'FREE', price: '0', period: 'forever',
              features: ['5 clip detections / month', '3 watermark removals / month', '2 AI video generations / month', '720p export quality'],
              inactive: ['Priority processing', 'API access', 'Custom branding'],
              featured: false, cta: 'GET STARTED FREE',
            },
            {
              tier: 'Creator', name: 'PRO', price: '49', period: 'per month',
              features: ['200 clip detections / month', '100 watermark removals / month', '50 AI video generations / month', '4K export quality', 'Priority processing', 'Bulk batch processing'],
              inactive: ['API access', 'White-label'],
              featured: true, cta: 'START PRO TRIAL',
            },
            {
              tier: 'Agency', name: 'SCALE', price: '199', period: 'per month',
              features: ['Unlimited clip detections', 'Unlimited watermark removals', '200 AI video generations / month', '4K export quality', 'Full REST API access', 'White-label & custom branding', 'Dedicated Slack support'],
              inactive: [],
              featured: false, cta: 'CONTACT SALES',
            },
          ].map(plan => (
            <div key={plan.name} style={{
              background: plan.featured ? 'linear-gradient(160deg,#130d09,#0d1117)' : '#0d1117',
              border: `1px solid ${plan.featured ? '#ff4d00' : '#1c2128'}`,
              borderRadius: 12, padding: 36,
              position: 'relative', overflow: 'hidden',
            }}>
              {plan.featured && (
                <div style={{
                  position: 'absolute', top: 20, right: -28,
                  background: '#ff4d00', color: '#050708',
                  fontSize: 9, letterSpacing: 2, fontWeight: 700,
                  padding: '4px 40px', transform: 'rotate(35deg)',
                }}>MOST POPULAR</div>
              )}
              <div style={{ fontSize: 10, letterSpacing: 3, textTransform: 'uppercase', color: '#6e7681', marginBottom: 12 }}>{plan.tier}</div>
              <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 28, letterSpacing: 1, marginBottom: 20 }}>{plan.name}</div>
              <div style={{ fontFamily: 'Anton, sans-serif', fontSize: 60, letterSpacing: -2, lineHeight: 1, marginBottom: 4 }}>
                <sup style={{ fontSize: '0.35em', verticalAlign: 'top', marginTop: '0.3em', display: 'inline-block' }}>$</sup>{plan.price}
              </div>
              <div style={{ fontSize: 11, color: '#6e7681', marginBottom: 28 }}>{plan.period}</div>
              <hr style={{ border: 'none', borderTop: '1px solid #1c2128', marginBottom: 24 }} />
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 32 }}>
                {plan.features.map(f => (
                  <li key={f} style={{ fontSize: 12, color: '#6e7681', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <span style={{ color: '#ff4d00', flexShrink: 0 }}>→</span>{f}
                  </li>
                ))}
                {plan.inactive.map(f => (
                  <li key={f} style={{ fontSize: 12, color: '#6e7681', opacity: 0.35, display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <span style={{ flexShrink: 0 }}>—</span>{f}
                  </li>
                ))}
              </ul>
              <Link href="/dashboard" style={{
                display: 'block', textAlign: 'center', textDecoration: 'none',
                fontFamily: 'Anton, sans-serif', fontSize: 16, letterSpacing: 2,
                padding: 14, borderRadius: 6,
                background: plan.featured ? '#ff4d00' : 'transparent',
                color: plan.featured ? '#050708' : '#f5f2ec',
                border: plan.featured ? 'none' : '1px solid #1c2128',
              }}>{plan.cta}</Link>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <div style={{
        margin: '0 48px 100px',
        border: '1px solid #1c2128', borderRadius: 16,
        padding: '80px 60px', textAlign: 'center',
        background: 'linear-gradient(160deg,#0d0905,#050708)',
        position: 'relative', overflow: 'hidden',
      }}>
        <h2 style={{ fontFamily: 'Anton, sans-serif', fontSize: 'clamp(40px,6vw,80px)', lineHeight: .95, marginBottom: 20 }}>
          READY TO GO<br />
          <span style={{ fontFamily: 'Instrument Serif, serif', fontStyle: 'italic', color: '#ff4d00' }}>viral?</span>
        </h2>
        <p style={{ fontSize: 13, color: '#6e7681', marginBottom: 36, lineHeight: 1.8 }}>
          Join 200+ creators already using ClipForge to 10× their output.<br />No credit card required.
        </p>
        <Link href="/dashboard" style={{
          fontFamily: 'Anton, sans-serif', fontSize: 20, letterSpacing: 2,
          padding: '18px 48px', borderRadius: 4, textDecoration: 'none',
          background: '#ff4d00', color: '#050708',
          boxShadow: '0 0 40px rgba(255,77,0,.3)',
          display: 'inline-block',
        }}>
          OPEN CLIPFORGE FREE →
        </Link>
      </div>

      {/* FOOTER */}
      <footer style={{
        borderTop: '1px solid #1c2128',
        padding: '40px 48px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20,
      }}>
        <span style={{ fontFamily: 'Anton, sans-serif', fontSize: 20, letterSpacing: 2 }}>
          CLIP<span style={{ color: '#ff4d00' }}>FORGE</span>
        </span>
        <div style={{ display: 'flex', gap: 28 }}>
          {['Features', 'Pricing', 'Dashboard', 'Privacy', 'Terms'].map(l => (
            <a key={l} href="#" style={{ fontSize: 11, letterSpacing: 1.5, color: '#6e7681', textDecoration: 'none', textTransform: 'uppercase' }}>{l}</a>
          ))}
        </div>
        <span style={{ fontSize: 10, letterSpacing: 1, color: 'rgba(110,118,129,.4)' }}>© 2026 ClipForge. All rights reserved.</span>
      </footer>
    </main>
  )
}
